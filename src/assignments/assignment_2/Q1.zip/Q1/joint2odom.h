#ifndef JOINT2ODOM_H
#define JOINT2ODOM_H

#include <publisher_subscriber.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/JointState.h>
#include <math.h>

double wheel_separation = 0.16; //so we can use it in all functions
double wheel_diameter = 0.1;

template<>
void Publisher_Subscriber<nav_msgs::Odometry , sensor_msgs::JointState>::subscriberCallback(const sensor_msgs::JointState::ConstPtr& receivedMsg)
{
 // INITIALIZATION
    double right_wheel_position= 0, right_wheel_velocity = 0, left_wheel_position = 0, left_wheel_velocity = 0, velocity_cg = 0;
    double w = 0, dx = 0, dy = 0, dtheta=0, dt=0;
    static double t_secs = 0, t_nsecs = 0, x=0, y=0, theta=0; //initialize static variables of seconds and nano seconds
    

    t_secs = receivedMsg->header.stamp.sec - t_secs; //get the change in time from last run using stamp from receivedMsg
    t_nsecs = receivedMsg->header.stamp.nsec - t_nsecs;
    dt = t_secs + 0.000000001 *  t_nsecs;
    
    for(size_t k = 0; k <  2 ; k++) //or from k = 0 to k = 1
  {
      //check if name field in receivedMsg is left_motor
      //take the position and velocity fields and assign them to corresponding wheel
    if (recievedMsg -> name[k] == "left_motor") 
    {
      left_wheel_position  = recievedMsg -> position[k];
      left_wheel_velocity  = recievedMsg -> velocity[k];
    }
    else if (recievedMsg -> name[k] == "right_motor")
    {
      right_wheel_position = recievedMsg -> position[k];
      right_wheel_velocity = recievedMsg -> velocity[k];
    }
  }

    //Differential Drive Kinematics
    w = (right_wheel_velocity - left_wheel_position) / wheel_separation; //angular velocity
    
    velocity_cg = (right_wheel_velocity + left_wheel_velocity) / 2; //velocity of centre of mass (assumed to be symmetric
    
    dx   = velocity_cg * dt * cos(theta);
    dy   = velocity_cg * dt * sin(theta);
    dtheta = velocity_cg*wheel_diameter*dt / wheel_separation;



    x += dx;
    y += dy;
    theta +=dtheta;
}


#endif // JOINT2ODOM_H
