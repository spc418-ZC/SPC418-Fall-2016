#ifndef LASERSCAN_MAX_H
#define LASERSCAN_MAX_H

#include <publisher_subscriber.h>
#include <sensor_msgs/LaserScan.h>
#include <math.h>
#include <std_msgs/Float64.h>




template<>
void Publisher_Subscriber<std_msgs::Float64 , sensor_msgs::LaserScan>::subscriberCallback(const sensor_msgs::JointState::ConstPtr& receivedMsg)
{

    std_msgs::Float64 laser_max=0;
    float max = 0;

    for(i=0; i < receivedMsg->intensities.size(); i++)
    {
        if(receivedMsg->intensities[i]>max)
        {
            max = receivedMsg->intensities;
        }

    }

    laser_max = (double) max;

    publisherObject.publish(laser_max);


}



#endif // LASERSCAN_MAX_H
