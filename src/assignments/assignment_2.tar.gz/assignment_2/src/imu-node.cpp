#include <imu.h>

int main(int argc, char **argv)
{
  // Set up ROS.
  ros::init(argc, argv, "imu_node");
  ros::Duration(3).sleep();
  IMU imu_pos_estimator("imu_data","pose2D",1000);
  ros::spin();
}
